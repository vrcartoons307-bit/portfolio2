# VIMA TECH Portfolio

Files:
- `index.html`
- `style.css`
- `script.js`

## GitHub Pages
Upload these three files to the root of a GitHub repository, then enable:
Settings → Pages → Deploy from a branch → main → / (root).

The site is static HTML/CSS/JS and needs no build step.
