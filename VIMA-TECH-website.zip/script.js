
const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);

window.addEventListener("load",()=>setTimeout(()=>$("#loadingScreen")?.classList.add("hide"),500));

const navbar=$("#navbar"), back=$("#backToTop");
window.addEventListener("scroll",()=>{
  navbar?.classList.toggle("scrolled",scrollY>30);
  back?.classList.toggle("show",scrollY>500);
  updateActive();
});
back?.addEventListener("click",()=>scrollTo({top:0,behavior:"smooth"}));

const hamburger=$("#hamburger"), navMenu=$("#navMenu");
hamburger?.addEventListener("click",()=>{
  const open=navMenu.classList.toggle("open");
  hamburger.setAttribute("aria-expanded",open);
});
$$(".nav-link").forEach(a=>a.addEventListener("click",()=>navMenu?.classList.remove("open")));

const words=["Web Developer","Frontend Developer","UI/UX Designer","Digital Creator"];
let wi=0, ci=0, deleting=false;
function type(){
  const el=$("#typingText"); if(!el)return;
  const word=words[wi];
  el.textContent=word.slice(0,ci);
  if(!deleting && ci<word.length){ci++;setTimeout(type,80)}
  else if(!deleting){deleting=true;setTimeout(type,1200)}
  else if(ci>0){ci--;setTimeout(type,45)}
  else{deleting=false;wi=(wi+1)%words.length;setTimeout(type,300)}
}
type();

const observer=new IntersectionObserver(entries=>{
  entries.forEach(e=>{
    if(e.isIntersecting){
      e.target.classList.add("visible");
      e.target.querySelectorAll?.(".skill-progress-bar").forEach(b=>b.style.width=(b.dataset.width||0)+"%");
      e.target.querySelectorAll?.(".stat-number").forEach(counter=>{
        if(counter.dataset.done)return;
        counter.dataset.done="1";
        const target=+counter.dataset.count; let n=0;
        const step=Math.max(1,Math.ceil(target/45));
        const tick=()=>{n=Math.min(target,n+step);counter.textContent=n+(target===100?"%":"+");if(n<target)requestAnimationFrame(tick)};
        tick();
      });
    }
  });
},{threshold:.15});
$$("section,.skill-card,.stat-card").forEach(el=>{el.classList.add("reveal");observer.observe(el)});

$$(".filter-btn").forEach(btn=>btn.addEventListener("click",()=>{
  $$(".filter-btn").forEach(x=>x.classList.remove("active"));btn.classList.add("active");
  const filter=btn.dataset.filter;
  $$(".project-card").forEach(card=>card.classList.toggle("hidden",filter!=="all"&&card.dataset.category!==filter));
}));

const form=$("#contactForm");
form?.addEventListener("submit",e=>{
  e.preventDefault();
  const fields=["name","email","subject","message"];let ok=true;
  fields.forEach(id=>{
    const input=$("#"+id), err=$("#"+id+"Error");
    if(!input.value.trim()){err.textContent="Please fill this field.";ok=false}else err.textContent="";
    if(id==="email" && input.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value)){err.textContent="Enter a valid email.";ok=false}
  });
  if(ok){
    const data=new FormData(form);
    const subject=encodeURIComponent(data.get("subject"));
    const body=encodeURIComponent(`Name: ${data.get("name")}\nEmail: ${data.get("email")}\n\n${data.get("message")}`);
    window.location.href=`mailto:hello@vimatech.com?subject=${subject}&body=${body}`;
  }
});

function updateActive(){
  const y=scrollY+150;
  $$("section[id]").forEach(sec=>{
    const active=y>=sec.offsetTop && y<sec.offsetTop+sec.offsetHeight;
    const link=$(`.nav-link[data-section="${sec.id}"]`);
    link?.classList.toggle("active",active);
  });
}
